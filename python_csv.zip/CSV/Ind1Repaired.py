import csv
import locale
import time

locale.setlocale(locale.LC_ALL, 'Russian_Russia.1251')
date = time.strptime(input("Введите ваше данные в виде: ДД ММ ГГГГ\n"), "%d %m %Y")
num_fails=0
with open('5.csv', 'r', encoding="utf8") as csv_file:
    reader = csv.reader(csv_file)
    k=0
    for row in reader:
        row[10] = row[10].replace(',', '.')
        if k!=0 and row[10] != '-' and len(row[0].split()) == 1:
            date_current = time.strptime(row[7], "%d %B %Y  %H:%M")
            if float(row[10]) < 6 and date_current > date:
                print(row[0], row[1], ", количество баллов: ", row[10], ", дата сдачи: ", date_current.tm_mday, date_current.tm_mon, date_current.tm_year)
                num_fails += 1
        else:
            k+=1
print("Всего неудачных попыток: ", num_fails)


